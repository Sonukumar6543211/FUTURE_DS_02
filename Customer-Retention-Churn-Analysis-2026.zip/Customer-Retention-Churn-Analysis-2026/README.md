# Customer Retention & Churn Analysis (2026)

## 📌 Project Overview
This project analyzes customer churn patterns for a subscription-based telecom company to identify retention drivers and revenue risks.

## 🎯 Business Objective
- Identify why customers churn
- Determine high-risk customer segments
- Analyze customer lifetime trends
- Provide actionable retention strategies

## 📊 Dataset
Telco Customer Churn Dataset (Kaggle)

## 🛠 Tools Used
- Python (Pandas, Matplotlib, Seaborn)
- Jupyter Notebook
- GitHub

## 🔍 Key Findings
- Month-to-month contract customers show highest churn.
- Low tenure customers are high risk.
- Higher monthly charges correlate with churn.

## 💡 Recommendations
1. Promote annual contracts with discounts
2. Improve early onboarding experience
3. Create bundled service offers
4. Introduce loyalty rewards

---
Developed for Data Science & Analytics Task 2 (2026)
